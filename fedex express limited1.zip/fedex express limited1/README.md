# Delivery Tracking & Operations (local upgrade)

This version keeps the existing HTML/CSS visual design and adds a Node.js/Express backend for secure Operations sign-in, persistent shipment records, tracking events, support tickets, and audit logging.

## Requirements
- Node.js 20 or newer (Node.js 22 LTS recommended)
- Internet access during `npm install` to download packages

## Start it in VS Code
1. Extract this folder and open it in VS Code.
2. Open **Terminal → New Terminal** in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://127.0.0.1:8000/` for the public website.
6. Open `http://127.0.0.1:8000/admin/login.html` to sign in to Operations.

### Preconfigured local Operations login
- Email: `mrlsalom@gmail.com`
- Password: `ChangeMe12345`

The password is stored only as a salted scrypt hash in `storage/data.json`, not as plaintext. This is a convenience for local review only. Before deploying publicly, run `npm run admin:create` and replace it with a unique, strong password that you have not used elsewhere.

The project ships with the two previous sample shipments so you can test tracking. New shipments are saved in `storage/data.json`, and the public tracking page reads from the same server-side records. Do not manually publish or share this data file. The server blocks direct HTTP access to `storage/`.

## What now works
- Server-side email/password authentication using Node.js `scrypt` password hashes.
- Rate-limited login attempts, session ID regeneration at login, HTTP-only/same-site cookies, CSRF checks for state-changing Operations requests, and server-side route protection.
- Operations overview statistics calculated from stored records.
- Create shipments with generated tracking/reference numbers.
- Edit shipment details, cancel shipments without erasing history, and add dated tracking events/status updates.
- Public tracking lookup by tracking number or reference against the server data.
- Support requests saved as tickets and visible in Operations.
- Reviews saved with `Pending` moderation status (they are not automatically approved).
- Recent administrative activity log.

## Configuration
For local testing, the app has a development-only fallback session secret. Before any non-local deployment:
1. Copy `.env.example` to `.env`.
2. Set `SESSION_SECRET` to a long, random secret (at least 32 characters).
3. Set `NODE_ENV=production` and configure HTTPS, reverse-proxy settings, backups, and server monitoring.
4. Use a production-grade persistent session store and review the deployment security settings before exposing the site to the internet.

The application binds to `127.0.0.1` by default and is intended for local review at this stage. Do not expose it publicly as-is. Shipment locations and statuses are entered by authorized staff; there is no live GPS or carrier API integration. The map also requires internet access. Verify rights to use company branding before public/commercial use.


## World maps and shipment route

The public homepage maps use standard OpenStreetMap tiles (no API key) with visible attribution and interactive zoom/pan controls. Normal tile use requires an internet connection and must follow the OpenStreetMap tile usage policy.

When creating or editing a shipment in Operations, enter the full current package address and the recipient destination, including city and country. On save, the app looks up coordinates for both addresses and stores them with the shipment. The public tracking page then shows both pins and a **red connecting line** between the recorded current location and recipient destination. If the address lookup cannot locate either address, the save is stopped and the form shows which address needs to be made more specific.

The red line connects the two recorded coordinates; it is a visual connector, not a live GPS trace or a road-by-road route. Current locations change only when Operations updates the current address/tracking event. The public map can be zoomed and panned worldwide.


### Map tile source update
The public and tracking maps use Esri World Street Map tiles (no API key configured in this project). Internet access is required, and usage is subject to Esri's terms and service availability. The tracking red line connects the saved coordinates for the recorded current location and recipient destination; it is not live GPS tracking.


## Latest UI changes
- The homepage hero now cycles through the original aircraft background and ten additional logistics backgrounds, changing every 10 seconds with a fade transition.
- The shipment tracking page no longer renders a map; it continues to show shipment status, origin, destination, current recorded location, and event timeline. The public homepage network map remains in place.
- The ten new hero backgrounds are stored in `assets/images/hero-slide-01.jpg` through `hero-slide-10.jpg`.


Hero slideshow polish: hero images have been moderately brightened and sharpened; the dark overlay is lighter for clearer photography; the slide-number counter has been removed. Background rotation remains automatic every 10 seconds.


## Shipment creation and delivery progress

- Shipment creation and editing save the addresses exactly as entered; they do not call an external geocoding service. Map coordinates are optional metadata and are not required to create a record.
- In Operations → Shipments, use the Delivery progress slider or percentage field to set a whole-number value from 0 to 100.
- The public tracking page displays a horizontal progress line filled from the left edge to the saved percentage, along with the percentage label.
- Set progress to reflect the latest verified operational milestone.
