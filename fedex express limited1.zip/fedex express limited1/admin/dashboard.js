let csrfToken = '', shipments = [];
const $ = s => document.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = v => v ? new Date(v).toLocaleString() : '—';
const statusClass = s => s === 'Delivered' ? 'delivered' : ['Delivery exception','Delivery attempted'].includes(s) ? 'exception' : s === 'Cancelled' ? 'cancelled' : '';
async function api(url, options={}) {
  const headers = { ...(options.body ? {'Content-Type':'application/json'} : {}), ...(options.method && options.method !== 'GET' ? {'X-CSRF-Token':csrfToken} : {}), ...(options.headers||{}) };
  const response = await fetch(url, { credentials:'same-origin', ...options, headers });
  if (response.status === 401) { location.replace('/admin/login.html'); throw new Error('Your session has expired. Please sign in again.'); }
  const body = await response.json().catch(()=>({error:'Unexpected server response.'}));
  if (!response.ok) throw new Error(body.error || 'Request failed.');
  return body;
}
function alertMsg(text, error=false) { const box=$('#alertBox'); box.textContent=text; box.classList.toggle('error',error); box.hidden=false; window.scrollTo({top:0,behavior:'smooth'}); setTimeout(()=>box.hidden=true,6500); }
function shipmentRows(list, target) {
  const el=$(target);
  if (!list.length) { el.innerHTML='<tr><td colspan="6" class="ops-empty">No shipment records found.</td></tr>'; return; }
  el.innerHTML=list.map(s=>`<tr><td><span class="track-code">${esc(s.tracking)}</span><br><small class="ops-muted">${esc(s.reference||'')}</small></td><td>${esc(s.recipient||'—')}</td><td>${esc(s.origin)}<br><small class="ops-muted">to ${esc(s.destination)}</small></td><td><span class="ops-status ${statusClass(s.status)}">${esc(s.status)}</span></td><td><div class="ops-progress"><i style="width:${Math.max(0,Math.min(100,Number(s.progress)||0))}%"></i></div><small>${Math.max(0,Math.min(100,Number(s.progress)||0))}%</small></td><td><div class="ops-inline-actions"><button class="ops-btn" data-action="edit-shipment" data-tracking="${esc(s.tracking)}">Edit</button><button class="ops-btn" data-action="events" data-tracking="${esc(s.tracking)}">Events</button><button class="ops-btn" data-action="cancel-shipment" data-tracking="${esc(s.tracking)}">Cancel</button></div></td></tr>`).join('');
}
async function loadShipments(q='') {
  const d=await api('/api/operations/shipments'+(q?'?q='+encodeURIComponent(q):'')); shipments=d.shipments;
  shipmentRows(shipments,'#shipmentRows'); shipmentRows(shipments.slice(0,8),'#recentRows');
  const select=$('#eventShipment'), selected=select.value;
  select.innerHTML='<option value="">Choose a shipment…</option>'+shipments.filter(s=>s.status!=='Cancelled').map(s=>`<option value="${esc(s.tracking)}">${esc(s.tracking)} — ${esc(s.origin)} → ${esc(s.destination)}</option>`).join('');
  if (shipments.some(s=>s.tracking===selected)) select.value=selected;
}
async function loadSummary() { const d=await api('/api/operations/summary'); $('#metricTotal').textContent=d.total; $('#metricTransit').textContent=d.inTransit; $('#metricDelivered').textContent=d.delivered; $('#metricExceptions').textContent=d.exceptions; }
async function loadTickets() { const d=await api('/api/operations/tickets'); $('#ticketRows').innerHTML=d.tickets.length?d.tickets.map(t=>`<tr><td>${esc(t.id)}</td><td>${esc(t.tracking||'—')}</td><td>${esc(t.email)}</td><td>${esc(t.type)}</td><td><span class="ops-status">${esc(t.status)}</span></td><td>${fmt(t.createdAt)}</td><td><select aria-label="Ticket status" data-ticket-status="${esc(t.id)}"><option ${t.status==='Open'?'selected':''}>Open</option><option ${t.status==='In progress'?'selected':''}>In progress</option><option ${t.status==='Resolved'?'selected':''}>Resolved</option><option ${t.status==='Closed'?'selected':''}>Closed</option></select></td></tr>`).join(''):'<tr><td colspan="7" class="ops-empty">No support tickets yet.</td></tr>';  }
async function loadAudit() { const d=await api('/api/operations/audit'); $('#auditRows').innerHTML=d.logs.length?d.logs.map(l=>`<tr><td>${fmt(l.at)}</td><td>${esc(l.user)}</td><td>${esc(l.action)}</td><td>${esc(l.target)}</td><td>${esc(l.details)}</td></tr>`).join(''):'<tr><td colspan="5" class="ops-empty">No activity recorded yet.</td></tr>'; }
async function refresh() { await Promise.all([loadSummary(),loadShipments(),loadTickets(),loadAudit()]); }
function switchView(view) { document.querySelectorAll('[id^="view-"]').forEach(el=>el.classList.toggle('hidden',el.id!==`view-${view}`)); document.querySelectorAll('[data-view]').forEach(a=>a.classList.toggle('active',a.dataset.view===view)); const titles={overview:['Overview','Live summary of records saved in this local application.'],shipments:['Shipments','Create and manage shipment records.'],events:['Tracking events','Record operational checkpoints and update customer-visible tracking.'],support:['Support tickets','Review customer inquiries received through the public support form.'],activity:['Activity log','Recent sign-ins and important operations changes.']}; $('#viewTitle').textContent=titles[view][0]; $('#viewDescription').textContent=titles[view][1]; location.hash=view; }
function syncProgress(value) { const n=Math.max(0,Math.min(100,Number(value)||0)); $('#progressRange').value=n; $('#progressNumber').value=n; $('#progressPreview').textContent=n+'%'; $('#progressPreviewBar').style.width=n+'%'; }
function openNew() { switchView('shipments'); $('#shipmentEditor').classList.remove('hidden'); $('#shipmentForm').reset(); syncProgress(3); $('#shipmentMapStatus').textContent='Addresses are saved exactly as entered. Map lookup is optional and will not block shipment creation.'; $('#shipmentForm').dataset.editing=''; $('#shipmentForm').querySelector('button[type=submit]').textContent='Create and save shipment'; $('#shipmentEditor h2').textContent='Create shipment'; $('#shipmentEditor').scrollIntoView({behavior:'smooth',block:'start'}); }
async function openEdit(tracking) { const s=shipments.find(x=>x.tracking===tracking); if(!s) return; switchView('shipments'); $('#shipmentEditor').classList.remove('hidden'); const form=$('#shipmentForm'); form.reset(); form.dataset.editing=tracking; for(const field of ['sender','recipient','recipientEmail','service','origin','destination','current','eta','description','current_lat','current_lng','destination_lat','destination_lng']) if(form.elements[field]) form.elements[field].value=s[field]??''; syncProgress(s.progress ?? 3); $('#shipmentMapStatus').textContent='Addresses are saved exactly as entered. Map lookup is optional and will not block shipment updates.'; form.querySelector('button[type=submit]').textContent='Save shipment changes'; $('#shipmentEditor h2').textContent='Edit shipment '+tracking; $('#shipmentEditor').scrollIntoView({behavior:'smooth',block:'start'}); }
async function showEvents(tracking) { switchView('events'); $('#eventShipment').value=tracking; await loadEventHistory(tracking); }
async function loadEventHistory(tracking) { const s=shipments.find(x=>x.tracking===tracking); const el=$('#eventHistory'); if(!s){el.innerHTML='<p class="ops-muted">Select a shipment above to view its current history.</p>';return;} el.innerHTML=(s.events||[]).length?s.events.map(e=>{const title=Array.isArray(e)?e[0]:e.title,loc=Array.isArray(e)?e[1]:e.location,at=Array.isArray(e)?e[2]:e.at,desc=Array.isArray(e)?'':e.description;return `<article class="event-item"><b>${esc(title)}</b><p>${esc(loc||'Location not recorded')} · ${esc(desc||'')}</p><time>${esc(fmt(at))}</time></article>`}).join(''):'<p class="ops-muted">No tracking events have been recorded.</p>'; }
document.addEventListener('click',async e=>{const el=e.target.closest('[data-action]');if(!el)return;try{if(el.dataset.action==='new')openNew();if(el.dataset.action==='edit-shipment')await openEdit(el.dataset.tracking);if(el.dataset.action==='cancel-editor')$('#shipmentEditor').classList.add('hidden');if(el.dataset.action==='events')await showEvents(el.dataset.tracking);if(el.dataset.action==='cancel-shipment'){if(!confirm(`Cancel shipment ${el.dataset.tracking}? This records a cancellation event; it does not erase the shipment.`))return;await api('/api/operations/shipments/'+encodeURIComponent(el.dataset.tracking),{method:'DELETE'});await refresh();alertMsg('Shipment cancelled and history preserved.');}}catch(err){alertMsg(err.message,true)}});
document.querySelectorAll('[data-view]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();switchView(a.dataset.view)}));
document.addEventListener('change',async e=>{const select=e.target.closest('[data-ticket-status]');if(!select)return;try{await api('/api/operations/tickets/'+encodeURIComponent(select.dataset.ticketStatus),{method:'PATCH',body:JSON.stringify({status:select.value})});await loadTickets();await loadAudit();alertMsg('Support ticket status updated.')}catch(err){alertMsg(err.message,true)}});
$('#shipmentSearch').addEventListener('input',async e=>{try{await loadShipments(e.target.value.trim())}catch(err){alertMsg(err.message,true)}});
$('#progressRange').addEventListener('input', e=>syncProgress(e.target.value));
$('#progressNumber').addEventListener('input', e=>{ if(e.target.value===''){ $('#progressPreview').textContent='—'; return; } syncProgress(e.target.value); });
$('#shipmentForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const form=e.currentTarget;
  const body=Object.fromEntries(new FormData(form).entries());
  const button=$('#saveShipment');
  const mapStatus=$('#shipmentMapStatus');
  button.disabled=true;
  try {
    // Coordinates are optional metadata. Shipment creation never depends on an external geocoder.
    body.progress=String(Math.max(0,Math.min(100,Number(body.progress)||0)));
    mapStatus.textContent='Saving shipment details…';
    const editing=form.dataset.editing;
    const d=editing
      ? await api('/api/operations/shipments/'+encodeURIComponent(editing),{method:'PATCH',body:JSON.stringify(body)})
      : await api('/api/operations/shipments',{method:'POST',body:JSON.stringify(body)});
    await refresh();
    form.reset();
    syncProgress(3);
    form.dataset.editing='';
    $('#shipmentEditor').classList.add('hidden');
    if(editing){alertMsg(`Shipment ${editing} updated successfully.`)}
    else {alertMsg(`Shipment created. Tracking number: ${d.shipment.tracking}`); try { await navigator.clipboard?.writeText(d.shipment.tracking); } catch {} }
  } catch(err) {
    mapStatus.textContent=err.message;
    alertMsg(err.message,true);
  } finally { button.disabled=false; }
});
$('#eventShipment').addEventListener('change',e=>loadEventHistory(e.target.value));
$('#eventForm').addEventListener('submit',async e=>{e.preventDefault();const body=Object.fromEntries(new FormData(e.currentTarget).entries());const tracking=body.tracking;delete body.tracking;try{await api('/api/operations/shipments/'+encodeURIComponent(tracking)+'/events',{method:'POST',body:JSON.stringify(body)});await refresh();$('#eventShipment').value=tracking;await loadEventHistory(tracking);alertMsg('Tracking event saved and made available on the public tracking page.')}catch(err){alertMsg(err.message,true)}});
$('#logoutButton').addEventListener('click',async()=>{try{await api('/api/auth/logout',{method:'POST',body:'{}'});location.replace('/admin/login.html')}catch(err){alertMsg(err.message,true)}});
(async()=>{try{const status=await fetch('/api/auth/status',{credentials:'same-origin'}).then(r=>r.json());if(!status.authenticated){location.replace('/admin/login.html');return;}csrfToken=status.csrfToken;$('#userEmail').textContent=status.user.email;$('#userInitials').textContent=status.user.email.slice(0,2).toUpperCase();await refresh();const view=location.hash.slice(1);if(['overview','shipments','events','support','activity'].includes(view))switchView(view);}catch(err){alertMsg(err.message||'Unable to load dashboard.',true)}})();
