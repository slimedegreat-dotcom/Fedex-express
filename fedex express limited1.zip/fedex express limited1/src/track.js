const params = new URLSearchParams(location.search);
const query = (params.get('tracking') || '').trim();
const input = document.querySelector('#trackingInput');
const root = document.querySelector('#result');
input.value = query;
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const progressFor = status => ({'Shipment created':3,'Awaiting collection':8,'Collected':15,'Processing':22,'In transit':50,'Arrived at facility':65,'Customs clearance':72,'Out for delivery':90,'Delivery attempted':92,'Delivery exception':60,'Delivered':100,'Cancelled':0,'Returned to sender':15}[status] ?? 10);
function renderError(message) { root.innerHTML = `<div class="notice error">${esc(message)}</div>`; }
function renderShipment(ship) {
  document.querySelector('#trackTitle').textContent = `Shipment ${ship.tracking}`;
  root.innerHTML = `${ship.demo ? '<div class="notice">Sample record for local testing only. Confirm shipment details before using this information operationally.</div>' : ''}<div class="tracking-panel"><div class="shipment-head"><div><span class="status-pill">${esc(ship.status)}</span><h3>${esc(ship.tracking)}</h3><p>Reference ${esc(ship.reference || '—')} · ${esc(ship.service || 'Shipping service')}</p></div><div><small>ESTIMATED DELIVERY</small><b>${esc(ship.eta || 'Not available')}</b></div></div><div class="progress-heading"><span>Delivery progress</span><strong>${Math.max(0,Math.min(100,Number(ship.progress ?? progressFor(ship.status))))}%</strong></div><div class="progress" role="progressbar" aria-label="Delivery progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.max(0,Math.min(100,Number(ship.progress ?? progressFor(ship.status))))}"><i style="width:${Math.max(0,Math.min(100,Number(ship.progress ?? progressFor(ship.status))))}%"></i></div><div class="mini-row"><span>Origin</span><b>${esc(ship.origin || 'Not recorded')}</b></div><div class="mini-row"><span>Destination</span><b>${esc(ship.destination || 'Not recorded')}</b></div><div class="mini-row"><span>Current recorded location</span><b>${esc(ship.current || 'Not recorded')}</b></div><section class="timeline package-description"><h3>Package Description</h3><p>${esc(ship.description || 'No package description provided.')}</p></section></div>`;

}
if (!query) {
  root.innerHTML = '<div class="notice">Enter your tracking number or reference above to view the latest recorded shipment information.</div>';
} else {
  root.innerHTML = '<div class="notice">Looking up your shipment…</div>';
  fetch('/api/track/' + encodeURIComponent(query), {cache:'no-store'})
    .then(async response => { const body=await response.json(); if(!response.ok) throw new Error(body.error || 'Shipment not found.'); return body; })
    .then(body => renderShipment(body.shipment))
    .catch(err => renderError(err.message));
}
