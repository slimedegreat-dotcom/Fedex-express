import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import FileStoreFactory from 'session-file-store';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { sampleData } from './data.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 8000);
const NODE_ENV = process.env.NODE_ENV || 'development';
const SESSION_SECRET = process.env.SESSION_SECRET || (NODE_ENV === 'production' ? '' : 'local-development-secret-change-before-deployment-9d8b4f2c');
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error('SESSION_SECRET must be set to a random value of at least 32 characters.');
  process.exit(1);
}

const storageDir = path.join(__dirname, 'storage');
const dataFile = path.join(storageDir, 'data.json');
fs.mkdirSync(storageDir, { recursive: true });
fs.mkdirSync(path.join(storageDir, 'sessions'), { recursive: true });
if (!fs.existsSync(dataFile)) {
  fs.writeFileSync(dataFile, JSON.stringify({ ...sampleData, users: [], auditLogs: [] }, null, 2), { mode: 0o600 });
}
let data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
data.users ||= [];
data.auditLogs ||= [];
data.tickets ||= [];
data.reviews ||= [];
data.shipments ||= [];
function saveData() {
  const tmp = `${dataFile}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, dataFile);
}
function audit(user, action, target, details = '') {
  data.auditLogs.unshift({ id: crypto.randomUUID(), user: user?.email || 'system', action, target, details, at: new Date().toISOString() });
  data.auditLogs = data.auditLogs.slice(0, 1000);
  saveData();
}
const asyncWrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false, limit: '30kb' }));
const FileStore = FileStoreFactory(session);
app.use(session({
  name: 'ops.sid', secret: SESSION_SECRET, resave: false, saveUninitialized: false,
  store: new FileStore({ path: path.join(storageDir, 'sessions'), ttl: 30 * 60, reapInterval: 60 * 60, logFn: () => {}, secret: SESSION_SECRET }),
  cookie: { httpOnly: true, sameSite: 'lax', secure: NODE_ENV === 'production', maxAge: 30 * 60 * 1000 }
}));
app.use((req, res, next) => {
  let decodedPath;
  try { decodedPath = decodeURIComponent(req.path); } catch { return res.status(400).end(); }
  const resolved = path.resolve(__dirname, `.${decodedPath}`);
  const relative = path.relative(__dirname, resolved);
  if (relative.startsWith('..') || path.isAbsolute(relative)) return res.status(404).end();
  const first = relative.split(path.sep)[0].toLowerCase();
  if (['storage', 'scripts'].includes(first) || /^\.(env|git)(?:$|[.\/\\])/i.test(relative) || /^(server\.js|package\.json|package-lock\.json)$/i.test(relative)) return res.status(404).end();
  if (decodedPath === '/admin/dashboard.html' && !currentUser(req)) return res.redirect('/admin/login.html');
  next();
});
app.use(express.static(__dirname, { index: 'index.html', dotfiles: 'ignore', setHeaders(res, filePath) {
  if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-store');
}}));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many login attempts. Try again in 15 minutes.' } });
const normalize = value => String(value ?? '').trim();
const safeText = (value, max = 500) => normalize(value).slice(0, max);
const allowedStatuses = ['Shipment created', 'Awaiting collection', 'Collected', 'Processing', 'In transit', 'Arrived at facility', 'Customs clearance', 'Out for delivery', 'Delivery attempted', 'Delivery exception', 'Delivered', 'Cancelled', 'Returned to sender'];
const statusProgress = { 'Shipment created': 3, 'Awaiting collection': 8, 'Collected': 15, 'Processing': 22, 'In transit': 50, 'Arrived at facility': 65, 'Customs clearance': 72, 'Out for delivery': 90, 'Delivery attempted': 92, 'Delivery exception': 60, 'Delivered': 100, 'Cancelled': 0, 'Returned to sender': 15 };
function currentUser(req) { return req.session?.user || null; }
function requireAuth(req, res, next) {
  if (!currentUser(req)) return res.status(401).json({ error: 'Please sign in to Operations.' });
  next();
}
function csrfCheck(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const token = req.get('x-csrf-token');
  if (!token || !req.session.csrfToken || token.length !== req.session.csrfToken.length || !crypto.timingSafeEqual(Buffer.from(token), Buffer.from(req.session.csrfToken))) {
    return res.status(403).json({ error: 'Security token expired. Refresh the page and try again.' });
  }
  next();
}
function publicShipment(s) {
  return { tracking: s.tracking, reference: s.reference, service: s.service, demo: Boolean(s.demo), status: s.status, origin: s.origin, destination: s.destination, current: s.current, eta: s.eta, progress: s.progress, description: s.description || '', current_lat: s.current_lat ?? null, current_lng: s.current_lng ?? null, destination_lat: s.destination_lat ?? null, destination_lng: s.destination_lng ?? null };
}
function validEmail(s) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s); }

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.get('/api/auth/status', (req, res) => {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  res.set('Cache-Control', 'no-store').json({ authenticated: Boolean(currentUser(req)), user: currentUser(req), csrfToken: req.session.csrfToken });
});
app.post('/api/auth/login', loginLimiter, csrfCheck, asyncWrap(async (req, res) => {
  const email = normalize(req.body.email).toLowerCase();
  const password = String(req.body.password || '');
  const user = data.users.find(u => u.email.toLowerCase() === email && u.active !== false);
  const salt = user?.salt || 'invalid-user-salt';
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  const valid = Boolean(user && crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(user.passwordHash, 'hex')));
  if (!valid) {
    audit(null, 'login_failed', email || 'empty email');
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Could not create a secure session.' });
    req.session.user = { id: user.id, email: user.email, role: user.role };
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
    req.session.save(saveErr => {
      if (saveErr) return res.status(500).json({ error: 'Could not save your session.' });
      audit(user, 'login_success', user.email);
      res.set('Cache-Control', 'no-store').json({ ok: true, user: req.session.user, csrfToken: req.session.csrfToken });
    });
  });
}));
app.post('/api/auth/logout', requireAuth, csrfCheck, (req, res) => {
  const user = currentUser(req);
  audit(user, 'logout', user.email);
  req.session.destroy(() => { res.clearCookie('ops.sid', { httpOnly: true, sameSite: 'lax', secure: NODE_ENV === 'production' }); res.json({ ok: true }); });
});

app.get('/api/track/:query', (req, res) => {
  const q = safeText(req.params.query, 120).toLowerCase();
  const shipment = data.shipments.find(s => String(s.tracking).toLowerCase() === q || String(s.reference || '').toLowerCase() === q);
  res.set('Cache-Control', 'no-store');
  if (!shipment) return res.status(404).json({ error: 'No shipment was found for that tracking number or reference.' });
  res.json({ shipment: publicShipment(shipment) });
});

app.use('/api/operations', requireAuth, csrfCheck);
app.get('/api/operations/summary', (req, res) => {
  const shipments = data.shipments;
  res.set('Cache-Control', 'no-store').json({
    total: shipments.filter(s => s.status !== 'Cancelled').length,
    inTransit: shipments.filter(s => ['In transit','Arrived at facility','Customs clearance'].includes(s.status)).length,
    delivered: shipments.filter(s => s.status === 'Delivered').length,
    exceptions: shipments.filter(s => ['Delivery exception','Delivery attempted'].includes(s.status)).length,
    tickets: data.tickets.filter(t => !['Resolved','Closed'].includes(t.status)).length,
    recent: shipments.slice().sort((a,b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0)).slice(0, 8)
  });
});
app.get('/api/operations/shipments', (req, res) => {
  const q = safeText(req.query.q, 120).toLowerCase();
  const list = data.shipments.filter(s => !q || [s.tracking,s.reference,s.origin,s.destination,s.recipient].some(v => String(v || '').toLowerCase().includes(q)))
    .slice().sort((a,b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0));
  res.set('Cache-Control', 'no-store').json({ shipments: list });
});
app.post('/api/operations/shipments', (req, res) => {
  const body = req.body || {};
  const origin = safeText(body.origin, 250), destination = safeText(body.destination, 250);
  if (!origin || !destination) return res.status(400).json({ error: 'Origin and destination are required.' });
  const status = allowedStatuses.includes(body.status) ? body.status : 'Shipment created';
  const requestedProgress = body.progress === undefined || body.progress === '' ? statusProgress[status] : Number(body.progress);
  if (!Number.isInteger(requestedProgress) || requestedProgress < 0 || requestedProgress > 100) return res.status(400).json({ error: 'Delivery progress must be a whole number from 0 to 100.' });
  const now = new Date().toISOString();
  let tracking;
  do { tracking = `FEL-${new Date().toISOString().slice(0,10).replaceAll('-','')}-${crypto.randomInt(100000,999999)}-${crypto.randomInt(100,999)}`; }
  while (data.shipments.some(s => s.tracking === tracking));
  const shipment = {
    tracking, reference: `REF-${crypto.randomUUID().slice(0,8).toUpperCase()}`, service: safeText(body.service, 100) || 'International Express',
    status, origin, destination, current: safeText(body.current, 250) || origin, eta: safeText(body.eta, 100), progress: requestedProgress,
    current_lat: body.current_lat !== undefined && body.current_lat !== '' && Number.isFinite(Number(body.current_lat)) ? Number(body.current_lat) : null, current_lng: body.current_lng !== undefined && body.current_lng !== '' && Number.isFinite(Number(body.current_lng)) ? Number(body.current_lng) : null, destination_lat: body.destination_lat !== undefined && body.destination_lat !== '' && Number.isFinite(Number(body.destination_lat)) ? Number(body.destination_lat) : null, destination_lng: body.destination_lng !== undefined && body.destination_lng !== '' && Number.isFinite(Number(body.destination_lng)) ? Number(body.destination_lng) : null,
    sender: safeText(body.sender, 160), recipient: safeText(body.recipient, 160), recipientEmail: safeText(body.recipientEmail, 254),
    description: safeText(body.description, 500), createdAt: now, updatedAt: now,
    events: [{ title: 'Shipment created', location: origin, at: now, description: 'Shipment record created by Operations.' }]
  };
  data.shipments.unshift(shipment);
  audit(currentUser(req), 'shipment_created', tracking);
  res.status(201).json({ shipment });
});
app.get('/api/operations/shipments/:tracking', (req, res) => {
  const s = data.shipments.find(x => x.tracking === req.params.tracking);
  if (!s) return res.status(404).json({ error: 'Shipment not found.' });
  res.json({ shipment: s });
});
app.patch('/api/operations/shipments/:tracking', (req, res) => {
  const s = data.shipments.find(x => x.tracking === req.params.tracking);
  if (!s) return res.status(404).json({ error: 'Shipment not found.' });
  const b = req.body || {};
  for (const field of ['origin','destination','current','eta','service','sender','recipient','recipientEmail','description']) {
    if (b[field] !== undefined) s[field] = safeText(b[field], field === 'description' ? 500 : 254);
  }
  for (const field of ['current_lat','current_lng','destination_lat','destination_lng']) {
    if (b[field] !== undefined) {
      const value = Number(b[field]);
      if (!Number.isFinite(value) || (field.endsWith('_lat') && Math.abs(value)>90) || (field.endsWith('_lng') && Math.abs(value)>180)) return res.status(400).json({error:`Invalid map coordinate: ${field}.`});
      s[field] = value;
    }
  }
  if (b.status !== undefined) {
    if (!allowedStatuses.includes(b.status)) return res.status(400).json({ error: 'Invalid shipment status.' });
    s.status = b.status;
    if (b.progress === undefined) s.progress = statusProgress[b.status];
  }
  if (b.progress !== undefined) {
    const progress = Number(b.progress);
    if (!Number.isInteger(progress) || progress < 0 || progress > 100) return res.status(400).json({ error: 'Delivery progress must be a whole number from 0 to 100.' });
    s.progress = progress;
  }
  s.updatedAt = new Date().toISOString();
  audit(currentUser(req), 'shipment_updated', s.tracking, `Status: ${s.status}`);
  res.json({ shipment: s });
});
app.post('/api/operations/shipments/:tracking/events', (req, res) => {
  const s = data.shipments.find(x => x.tracking === req.params.tracking);
  if (!s) return res.status(404).json({ error: 'Shipment not found.' });
  const title = safeText(req.body.title, 120), location = safeText(req.body.location, 250), description = safeText(req.body.description, 500);
  if (!title || !location) return res.status(400).json({ error: 'Event and location are required.' });
  if (req.body.status && !allowedStatuses.includes(req.body.status)) return res.status(400).json({ error: 'Invalid shipment status.' });
  const event = { id: crypto.randomUUID(), title, location, description, at: new Date().toISOString(), by: currentUser(req).email };
  s.events ||= []; s.events.unshift(event); s.current = location;
  if (req.body.status) { s.status = req.body.status; s.progress = statusProgress[req.body.status]; }
  s.updatedAt = event.at;
  audit(currentUser(req), 'tracking_event_added', s.tracking, title);
  res.status(201).json({ shipment: s });
});
app.delete('/api/operations/shipments/:tracking', (req, res) => {
  const index = data.shipments.findIndex(s => s.tracking === req.params.tracking);
  if (index < 0) return res.status(404).json({ error: 'Shipment not found.' });
  const s = data.shipments[index];
  s.status = 'Cancelled'; s.progress = 0; s.updatedAt = new Date().toISOString();
  s.events ||= []; s.events.unshift({ id: crypto.randomUUID(), title: 'Shipment cancelled', location: 'Operations', description: 'Shipment cancelled by authorized operator.', at: s.updatedAt, by: currentUser(req).email });
  audit(currentUser(req), 'shipment_cancelled', s.tracking);
  res.json({ ok: true, shipment: s });
});
app.get('/api/operations/tickets', (req, res) => res.json({ tickets: data.tickets }));
app.patch('/api/operations/tickets/:id', (req, res) => {
  const ticket = data.tickets.find(t => t.id === req.params.id);
  if (!ticket) return res.status(404).json({ error: 'Ticket not found.' });
  const status = safeText(req.body.status, 30);
  if (!['Open', 'In progress', 'Resolved', 'Closed'].includes(status)) return res.status(400).json({ error: 'Invalid ticket status.' });
  ticket.status = status; ticket.updatedAt = new Date().toISOString();
  audit(currentUser(req), 'support_ticket_updated', ticket.id, status);
  res.json({ ticket });
});
app.get('/api/operations/audit', (req, res) => res.json({ logs: data.auditLogs.slice(0, 100) }));
app.post('/api/support', (req, res) => {
  const email = safeText(req.body.email, 254), message = safeText(req.body.message, 2000);
  if (!validEmail(email) || message.length < 8) return res.status(400).json({ error: 'Enter a valid email and a message of at least 8 characters.' });
  const ticket = { id: `TKT-${Date.now()}-${crypto.randomInt(100,999)}`, tracking: safeText(req.body.tracking, 120), email, type: safeText(req.body.type, 80) || 'Other', message, status: 'Open', createdAt: new Date().toISOString() };
  data.tickets.unshift(ticket); saveData();
  res.status(201).json({ ok: true, ticketId: ticket.id });
});
app.post('/api/reviews', (req, res) => {
  const name = safeText(req.body.name, 100), text = safeText(req.body.text, 1000), rating = Number(req.body.rating);
  if (!name || text.length < 5 || !Number.isInteger(rating) || rating < 1 || rating > 5) return res.status(400).json({ error: 'Enter your name, a review, and a rating from 1 to 5.' });
  data.reviews.unshift({ id: crypto.randomUUID(), name, text, rating, status: 'Pending', createdAt: new Date().toISOString() });
  saveData(); res.status(201).json({ ok: true, message: 'Thank you. Your review has been submitted for moderation.' });
});

app.get('/admin', (req, res) => res.redirect('/admin/login.html'));
app.get('/admin/dashboard.html', (req, res, next) => {
  if (!currentUser(req)) return res.redirect('/admin/login.html');
  next();
});
app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'An unexpected server error occurred.' });
});
app.listen(PORT, '127.0.0.1', () => console.log(`Operations tracking app running at http://127.0.0.1:${PORT}`));
