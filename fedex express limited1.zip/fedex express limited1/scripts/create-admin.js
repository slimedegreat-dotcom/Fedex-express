import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import readline from 'node:readline';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const file = path.join(root, 'storage', 'data.json');
if (!fs.existsSync(file)) {
  console.error('Data store not found. Run npm start once, stop it, then run npm run admin:create.');
  process.exit(1);
}
const data = JSON.parse(fs.readFileSync(file, 'utf8'));
data.users ||= [];
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = q => new Promise(resolve => rl.question(q, resolve));
function askPassword(prompt) {
  return new Promise(resolve => {
    process.stdout.write(prompt);
    let value = '';
    const stdin = process.stdin;
    stdin.setRawMode?.(true); stdin.resume();
    const onData = ch => {
      const s = ch.toString();
      if (s === '\u0003') { process.stdout.write('\n'); process.exit(1); }
      if (s === '\r' || s === '\n') { stdin.off('data', onData); stdin.setRawMode?.(false); process.stdout.write('\n'); resolve(value); return; }
      if (s === '\u007f' || s === '\b') { value = value.slice(0, -1); return; }
      if (s >= ' ') value += s;
    };
    stdin.on('data', onData);
  });
}
try {
  const email = (await ask('Administrator email: ')).trim().toLowerCase();
  rl.close();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Enter a valid email address.');
  const password = await askPassword('Password (minimum 12 characters): ');
  if (password.length < 12) throw new Error('Password must be at least 12 characters.');
  const confirm = await askPassword('Confirm password: ');
  if (password !== confirm) throw new Error('Passwords do not match.');
  const salt = crypto.randomBytes(16).toString('hex');
  const passwordHash = crypto.scryptSync(password, salt, 64).toString('hex');
  const existing = data.users.find(u => u.email.toLowerCase() === email);
  const user = { id: existing?.id || crypto.randomUUID(), email, salt, passwordHash, role: 'super_admin', active: true, createdAt: existing?.createdAt || new Date().toISOString() };
  if (existing) data.users[data.users.indexOf(existing)] = user; else data.users.push(user);
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { mode: 0o600 }); fs.renameSync(tmp, file);
  console.log(`Administrator account saved for ${email}. You can now sign in at /admin/login.html.`);
} catch (e) { console.error(e.message); process.exitCode = 1; }
finally { try { rl.close(); } catch {} }
