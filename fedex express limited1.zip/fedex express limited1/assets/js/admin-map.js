document.addEventListener('DOMContentLoaded', () => {
  const current = document.getElementById('currentAddress');
  const destination = document.getElementById('destinationAddress');
  const locateBtn = document.getElementById('locateShipment');
  const status = document.getElementById('geocodeStatus');
  if (!current || !destination || !locateBtn) return;

  const fields = {
    current: [document.getElementById('currentLat'), document.getElementById('currentLng')],
    destination: [document.getElementById('destinationLat'), document.getElementById('destinationLng')]
  };

  const setStatus = (text, bad = false) => {
    if (!status) return;
    status.textContent = text;
    status.classList.toggle('error-text', bad);
  };

  async function geocode(address) {
    const url = new URL('https://nominatim.openstreetmap.org/search');
    url.searchParams.set('q', address);
    url.searchParams.set('format', 'jsonv2');
    url.searchParams.set('limit', '1');
    const res = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('Map service unavailable');
    const rows = await res.json();
    if (!rows.length) throw new Error(`Address not found: ${address}`);
    return { lat: Number(rows[0].lat), lng: Number(rows[0].lon) };
  }

  // Map lookup is deliberately optional. It never intercepts or replaces the
  // shipment form's native POST/save operation.
  locateBtn.addEventListener('click', async () => {
    const currentAddress = current.value.trim();
    const destinationAddress = destination.value.trim();
    if (!currentAddress || !destinationAddress) {
      setStatus('Enter both addresses first.', true);
      return;
    }
    locateBtn.disabled = true;
    setStatus('Locating addresses…');
    try {
      const [c, d] = await Promise.all([geocode(currentAddress), geocode(destinationAddress)]);
      fields.current[0].value = c.lat;
      fields.current[1].value = c.lng;
      fields.destination[0].value = d.lat;
      fields.destination[1].value = d.lng;
      setStatus('✓ Locations found. You can now save the shipment.');
    } catch (err) {
      setStatus('Map lookup failed. You can still save the shipment normally.', true);
    } finally {
      locateBtn.disabled = false;
    }
  });
});
