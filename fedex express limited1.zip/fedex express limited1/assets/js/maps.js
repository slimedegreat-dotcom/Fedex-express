document.addEventListener('DOMContentLoaded', () => {
  if (!window.L) return;
  // Standard OpenStreetMap raster tiles: no API key required. Use them for normal,
  // interactive browsing and preserve the required attribution.
  const tile = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
  const attr = 'Tiles &copy; Esri &mdash; Sources: Esri, HERE, Garmin, USGS, Intermap, INCREMENT P, NRCan, Esri Japan, METI, Esri China (Hong Kong), OpenStreetMap contributors, and the GIS User Community';
  const addBase = map => L.tileLayer(tile, { attribution: attr, maxZoom: 19, maxNativeZoom: 19 }).addTo(map);
  function addPin(map, lat, lng, label, type) {
    const icon = L.divIcon({ className: 'eed-map-pin-wrap', html: `<span class="eed-map-pin ${type}">📍</span>`, iconSize: [34,34], iconAnchor: [17,30], popupAnchor: [0,-28] });
    return L.marker([lat,lng], {icon}).addTo(map).bindPopup(`<b>${label}</b>`);
  }
  function worldMap(el, center=[20,0], zoom=2) {
    const map = L.map(el, { scrollWheelZoom: true, worldCopyJump: true, minZoom: 2, maxZoom: 19 }).setView(center, zoom);
    addBase(map);
    L.control.scale().addTo(map);
    return map;
  }
  function drawShipmentMap(el) {
    const current = { label: el.dataset.currentLabel || 'Current package location', lat: Number(el.dataset.currentLat), lng: Number(el.dataset.currentLng) };
    const destination = { label: el.dataset.destinationLabel || 'Recipient destination', lat: Number(el.dataset.destinationLat), lng: Number(el.dataset.destinationLng) };
    const valid = [current,destination].every(p => Number.isFinite(p.lat) && Number.isFinite(p.lng) && Math.abs(p.lat)<=90 && Math.abs(p.lng)<=180);
    const map = worldMap(el, valid ? [current.lat,current.lng] : [20,0], valid ? 5 : 2);
    if (!valid) return;
    addPin(map,current.lat,current.lng,current.label,'current').openPopup();
    addPin(map,destination.lat,destination.lng,destination.label,'destination');
    const bounds = L.latLngBounds([[current.lat,current.lng],[destination.lat,destination.lng]]);
    // Red connector clearly links the recorded package location to the recipient address.
    L.polyline([[current.lat,current.lng],[destination.lat,destination.lng]], { color:'#e02020', weight:5, opacity:.95, lineCap:'round' }).addTo(map);
    map.fitBounds(bounds, {padding:[42,42], maxZoom: 12});
  }
  const tracking = document.querySelector('#trackingMap');
  if (tracking) drawShipmentMap(tracking);
  const hero = document.querySelector('#heroMap');
  if (hero) {
    const map = worldMap(hero, [20,0], 2);
    const hubs = [['New York',40.7128,-74.006],['London',51.5072,-0.1276],['Dubai',25.2048,55.2708],['Singapore',1.3521,103.8198],['Sydney',-33.8688,151.2093]];
    hubs.forEach(([name,lat,lng]) => L.circleMarker([lat,lng], {radius:6,color:'#071a31',fillColor:'#f5b51b',fillOpacity:1,weight:2}).addTo(map).bindTooltip(name));
  }
  const network = document.querySelector('#networkMap');
  if (network) {
    const map = worldMap(network, [20,0], 2);
    const hubs = [['Washington',38.9072,-77.0369],['New York',40.7128,-74.006],['London',51.5072,-0.1276],['Dubai',25.2048,55.2708],['Singapore',1.3521,103.8198],['Sydney',-33.8688,151.2093]];
    hubs.forEach(([name,lat,lng]) => L.circleMarker([lat,lng], {radius:7,color:'#071a31',fillColor:'#f5b51b',fillOpacity:1,weight:2}).addTo(map).bindTooltip(name));
  }
});
