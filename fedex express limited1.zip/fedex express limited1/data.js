export const sampleData = {
  "company": {
    "name": "FedEx Express Limited",
    "short": "FEL",
    "address": "144 Wacko Street, Washington, DC"
  },
  "shipments": [
    {
      "tracking": "FEL-20260930-225626-660",
      "reference": "FEL-REF-20260930225626-908",
      "service": "International Express",
      "status": "Processing",
      "origin": "Origin not recorded",
      "destination": "19035 Amoco Drive   South  Alvin , Texas  77511 USA",
      "current": "Via Ceresio 12, 20154 Milano, Italy",
      "current_lat": null,
      "current_lng": null,
      "destination_lat": null,
      "destination_lng": null,
      "eta": "",
      "progress": 7,
      "route": [],
      "events": [],
      "demo": true
    },
    {
      "tracking": "FEL-20260930-225045-690",
      "reference": "FEL-REF-20260930225045-290",
      "service": "International Express",
      "status": "Processing",
      "origin": "AGULU",
      "destination": "19035 Amoco Drive   South  Alvin , Texas  77511 USA",
      "current": "Via Ceresio 12, 20154 Milano, Italy",
      "current_lat": null,
      "current_lng": null,
      "destination_lat": null,
      "destination_lng": null,
      "eta": "",
      "progress": 12,
      "route": [],
      "events": [],
      "demo": true
    }
  ],
  "reviews": [
    {
      "name": "Amelia R.",
      "initials": "AR",
      "rating": 5,
      "text": "The tracking updates were clear and easy to follow."
    },
    {
      "name": "Daniel K.",
      "initials": "DK",
      "rating": 5,
      "text": "I could see each major checkpoint without confusion."
    },
    {
      "name": "Sarah M.",
      "initials": "SM",
      "rating": 4,
      "text": "Professional service and useful delivery notifications."
    }
  ],
  "tickets": []
};
